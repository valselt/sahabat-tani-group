# TanamanHias > 2024-10-22 4:02am
https://universe.roboflow.com/massive-3wfsw/tanamanhias

Provided by a Roboflow user
License: CC BY 4.0

