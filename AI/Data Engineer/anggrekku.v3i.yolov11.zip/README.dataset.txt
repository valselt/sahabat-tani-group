# anggrekku > 2024-10-27 9:10am
https://universe.roboflow.com/massivesegmentation/anggrekku

Provided by a Roboflow user
License: CC BY 4.0

