# mawar 2 > 2024-10-29 1:02pm
https://universe.roboflow.com/massivedetection/mawar-2

Provided by a Roboflow user
License: CC BY 4.0

