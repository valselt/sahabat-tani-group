# Persian Car Plates > 2024-09-13 9:46am
https://universe.roboflow.com/nimaworkspace01/persian-car-plates-qyefp

Provided by a Roboflow user
License: CC BY 4.0

